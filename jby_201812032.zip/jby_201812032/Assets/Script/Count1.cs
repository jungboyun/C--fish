﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Count1 : MonoBehaviour
{
    private float GameTime = 61;
    public Text GameTimeText;

    // Update is called once per frame
    void Update()
    {
        if ((int)GameTime == 0)
        {
            SceneManager.LoadScene("ClearScene");
        }
        else
        {
            GameTime = GameTime - Time.deltaTime;
            Debug.Log((int)GameTime);
            GameTimeText.text = "Time:" + (int)GameTime;
        }
    }
}
