﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class fish2Generator : MonoBehaviour
{
    public GameObject fish2Prefab;
    float span = 2.0f;
    float delta = 0;

    // Update is called once per frame
    void Update()
    {
        this.delta += Time.deltaTime;
        if (this.delta > this.span)
        {
            this.delta = 0;
            GameObject go = Instantiate(fish2Prefab) as GameObject;
            int px = Random.Range(-5, 5);
            go.transform.position = new Vector3(-7, px, 0);
        }
    }
}
