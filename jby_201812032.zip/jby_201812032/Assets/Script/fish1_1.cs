﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class fish1_1 : MonoBehaviour
{
    Rigidbody2D rigid2D;
    float speed = 2;
    int count = 0;
    public Text Text;
    GameObject fish2;

    void Start()
    {
        this.fish2 = GameObject.Find("fish2");
        this.rigid2D = GetComponent<Rigidbody2D>();
        Text.text = "2ROUND     Count: " + count.ToString();
    }
    void Update()
    {
        if (Input.GetKey(KeyCode.UpArrow))
        {
            this.transform.Translate(0, speed * Time.deltaTime, 0);
        }

        if (Input.GetKey(KeyCode.DownArrow))
        {
            this.transform.Translate(0, -speed * Time.deltaTime, 0);
        }

        if (Input.GetKey(KeyCode.LeftArrow))
        {
            this.transform.Translate(-speed * Time.deltaTime, 0, 0);
            transform.localScale = new Vector3(-0.2f, 0.2f, 0.2f);
        }

        if (Input.GetKey(KeyCode.RightArrow))
        {
            this.transform.Translate(speed * Time.deltaTime, 0, 0);
            transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
        }

    }

    void OnTriggerEnter2D(Collider2D fish2)
    {
            GetComponent<AudioSource>().Play();
            count = count + 10;
            Text.text = "2ROUND     Count: " + count.ToString();
        if (count >= 100)
        {
            SceneManager.LoadScene("SuccessScene");
        }
    }

    }
