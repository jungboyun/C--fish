﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class fish4_1 : MonoBehaviour
{

    GameObject fish1;
    // Start is called before the first frame update
    void Start()
    {
        this.fish1 = GameObject.Find("fish1");
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(0.1f, 0, 0);

        if (transform.position.x < -2.0f & transform.position.x > 2.0f)
        {
            Destroy(fish1.gameObject);
        }

        Vector2 p1 = transform.position;
        Vector2 p2 = this.fish1.transform.position;
        Vector2 dir = p1 - p2;
        float d = dir.magnitude;
        float r1 = 0.7f;
        float r2 = 0.5f;

        if (d < r1 + r2)
        {
            Destroy(fish1.gameObject);
            SceneManager.LoadScene("ClearScene");
        }
    }
}
